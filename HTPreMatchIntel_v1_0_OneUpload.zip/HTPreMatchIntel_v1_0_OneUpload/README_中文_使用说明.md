# HTPreMatchIntel v1.0 · 独立赛前情报研究 App

**仓库建议名：** `HTPreMatchIntel-Android`  
**包名：** `com.htintel.news`  
**应用名：** 赛前情报研究  
**最低要求：** Android 8.0 / API 26  
**依赖：** API-Football v3、可选 OpenAI 兼容 AI API、Google News RSS、Google ML Kit OCR（内置拉丁文字模型）

## 直接制作安装 APK

1. 前往 <https://github.com/new>，创建一个公开或私有的空仓库，建议名称 `HTPreMatchIntel-Android`，不勾选初始化README。
2. **解压本 ZIP**，把内部文件及 `.github` 隐藏目录完整上传到仓库根目录。注意不要上传外层 `HTPreMatchIntel_v1_0_OneUpload` 文件夹本身。
3. 打开仓库的 **Actions** 页，选择 **Build independent Android APK** → **Run workflow**。
4. 编译完成后，在 Workflow run 的 Artifacts 中下载 `HTPreMatchIntel_v1_0_Independent_APK`，解压得到 `app-debug.apk`。
5. 在 Android 手机上安装调试APK（需要允许该来源安装应用）。安装包名与旧筛选App不同，可以并存。

> 交付内容为可以直接交给GitHub Actions编译的Android项目源码；此环境缺少Android SDK及Gradle，未能在本地完成APK的实际编译或安装测试，因此不冒充已生成的APK。

## 研究流程

1. 上传比赛卡片截图，ML Kit本机OCR提取 Fixture ID 和 `主队 vs 客队`，识别后可以手工纠正。
2. 足球API根据 `Fixture ID` 唯一匹配比赛，核对比赛开始时间、赛事、主客队ID。
3. 拉取双方最近30场中的**最多10场同联赛且在比赛开赛前已结束**的比赛（不把全场比分当半场比分）。计算：
   - 半场进球、失球场均值，以及0-0出现次数；
   - 半场是否曾进球、是否失球、半场至少2球的分布；
   - 可选用最近3场进球事件核对0–15、16–30、31–45分钟进失球时段；对事件与半场比分不一致的场次拒绝统计；
   - 两队近期比赛的全场结果和半场比分明细；
   - 主队仅主场、客队仅客场半场表现；
   - 按当前联赛排名，把历史对手分为强/中/弱，并展示分组半场进失球。
4. 读取对应场次的伤停/停赛接口和官方首发接口；若打开「深入比对」，与过去两场常用首发交叉核对，区分**未首发但坐替补**和**不在阵容名单**。不可自动断言球员受伤。
5. 分别检索两支球队的Google News波兰语RSS标题、来源和发布时间，只保留距开赛前21天内且没有超过开赛时间的文章，提供点开原文的链接。
6. 配置可选的 OpenAI 兼容 `/chat/completions` API，使用可验证的数据与新闻链接生成中文结构化报告；缺失或未验证内容明确标注。

### 所需配置

- **足球API密钥：** 申请 <https://www.api-football.com/> 的 API-FOOTBALL v3 密钥，App发出请求时使用 `x-apisports-key` 请求头。
- **AI API密钥：** 可留空，App仍显示客观统计及新闻。若启用，应填写支持 `POST /chat/completions` 的HTTPS完整URL及服务商支持的模型名；不同厂商API协议并不一定兼容。
- 账号免费额度、联赛覆盖、伤停和首发数据可用性取决于用户API订阅与赛事本身。每次研究通常调用6次足球API，加上历史首发对比最多额外4次，再加上可选进球时段核对最多额外6次（总计最多约16次）；另外最多2次RSS及1次AI请求。
- 密钥在手机的 Android KeyStore 生成的AES-GCM密钥下本机加密保存；不应硬编码进源码、GitHub仓库或截图。

## 使用边界（重点）

- III Liga等低级别联赛的API伤停、首发甚至上半场比分可能缺失。没有返回数据**不等于没有伤停或轮换**。
- RSS新闻只能识别标题和来源，不可仅凭标题确认具体伤病。必须打开原文检查。
- 对手强弱分层使用查询时的**当前排名**，不是比赛当时的历史排名。不能使用它做严格历史无偏回测。
- 对旧比赛进行历史回看，`fixtures?last=30`可能无法覆盖当时最近10场，新闻RSS也无法保证复原当时新闻档案。这属于数据源局限，不应把它当作可靠历史复盘。
- 情报评级A级/B级/C级/PASS是**资料质量等级**，不是进球胜率或投注建议。
- 此版本没有后台自动提醒、定时轮询、赔率判断或自动下注功能；只有手动触发研究，结果仅作为筛选参考。

## 主要代码

- `app/src/main/java/com/htintel/news/MainActivity.java`：界面、截图OCR、配置、报告、新闻链接。
- `app/src/main/java/com/htintel/news/ResearchEngine.java`：API请求、比赛定位、半场统计、排名分层、伤停轮换、RSS及AI结构化总结。
- `app/src/main/java/com/htintel/news/SecretStore.java`：AndroidKeyStore AES-GCM本机加密。
- `.github/workflows/build-apk.yml`：GitHub Actions自动构建独立调试APK。

## 测试案例

截图：2026-11-18 13:00（阿根廷时间）  
主队 Barycz Sułów  
客队 Polonia Nysa  
Fixture ID `1568556`  
对应赛事：波兰 III Liga - Group 3；波兰当地开赛时间为17:00。

**注意：** 官网新闻与新闻RSS的内容可能更新；需要真实API密钥和互联网才能验证App中的接口返回，并不能用当前示例预测特定比分。
