package com.htintel.news;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** AndroidKeyStore-backed local AES-GCM credentials; never logs secrets. */
final class SecretStore {
    private static final String ALIAS="HTPreMatchIntelLocalKey";
    private static final String PREF="protected_credentials";
    static void save(Context context,String name,String plaintext) throws Exception {
        SharedPreferences pref=context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        if(plaintext==null||plaintext.isEmpty()){pref.edit().remove(name).apply();return;}
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] encrypted=cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
        String iv=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP);
        String body=Base64.encodeToString(encrypted,Base64.NO_WRAP);
        pref.edit().putString(name,"v1:"+iv+":"+body).apply();
    }
    static String load(Context context,String name) {
        try {
            String value=context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(name,"");
            if(!value.startsWith("v1:"))return "";
            String[] parts=value.split(":",3);if(parts.length!=3)return "";
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[1],Base64.NO_WRAP)));
            return new String(cipher.doFinal(Base64.decode(parts[2],Base64.NO_WRAP)),StandardCharsets.UTF_8);
        }catch(Exception e){return "";}
    }
    private static SecretKey key()throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(store.containsAlias(ALIAS))return ((KeyStore.SecretKeyEntry)store.getEntry(ALIAS,null)).getSecretKey();
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build());
        return generator.generateKey();
    }
}
