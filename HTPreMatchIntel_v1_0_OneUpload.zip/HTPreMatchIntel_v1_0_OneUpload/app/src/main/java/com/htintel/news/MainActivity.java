package com.htintel.news;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final int PICK_IMAGE=101;
    private static final int BG=0xff071821, CARD=0xff102d38, CARD2=0xff173945;
    private static final int WHITE=0xffedf8fa, SECONDARY=0xffb2ccd3, ACCENT=0xff66ead3, WARN=0xffffcc80;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ResearchEngine.Config config=new ResearchEngine.Config();
    private EditText fixtureId,home,away,apiKey,aiKey,aiEndpoint,aiModel;
    private CheckBox deepCheck,timingCheck;
    private TextView status,ocrPreview,aiContent,factsContent,warningsContent;
    private LinearLayout newsContainer,settingsArea,detailArea;
    private Button analyzeButton;
    private ResearchEngine.Report latest;
    private String screenshotKickoff="";
    private boolean detailsOpen=false;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences("ht_pre_match_options",MODE_PRIVATE);
        config.footballKey=SecretStore.load(this,"football");
        config.aiKey=SecretStore.load(this,"ai");
        config.aiEndpoint=prefs.getString("ai_endpoint",config.aiEndpoint);
        config.aiModel=prefs.getString("ai_model",config.aiModel);
        config.rotationDeepCheck=prefs.getBoolean("rotation",true);
        config.goalTimingCheck=prefs.getBoolean("timing",false);
        buildUi();
    }
    private void buildUi() {
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(25),dp(16),dp(50));
        scroll.addView(root);setContentView(scroll);

        TextView brand=label("赛前情报研究",28,ACCENT,true);root.addView(brand);
        root.addView(label("Fixture ID → 足球API → 新闻核查 → AI综合研究",12,SECONDARY,false));
        root.addView(gap(14));

        LinearLayout inputCard=card(root);
        inputCard.addView(label("01 · 识别比赛",19,WHITE,true));
        inputCard.addView(label("上传一张比赛图片，优先识别 Fixture ID；也可以直接输入。",12,SECONDARY,false));
        Button pick=button("选择图片 / OCR识别",false);inputCard.addView(pick);
        pick.setOnClickListener(v->{Intent intent=new Intent(Intent.ACTION_GET_CONTENT);intent.setType("image/*");intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(intent,"选择比赛截图"),PICK_IMAGE);});
        fixtureId=field("Fixture ID（例如1568556）","",false);inputCard.addView(fixtureId);
        home=field("主队名称（无Fixture ID时必填）","",false);inputCard.addView(home);
        away=field("客队名称（无Fixture ID时必填）","",false);inputCard.addView(away);
        Button example=button("填入这次截图的测试比赛",false);inputCard.addView(example);
        example.setOnClickListener(v->{fixtureId.setText("1568556");home.setText("Barycz Sułów");away.setText("Polonia Nysa");ocrPreview.setText("示例：2026-11-18 13:00（截图本地时间）");});
        ocrPreview=label("",12,SECONDARY,false);inputCard.addView(ocrPreview);
        analyzeButton=button("开始赛前情报研究",true);inputCard.addView(analyzeButton);
        analyzeButton.setOnClickListener(v->runAnalysis());
        status=label("准备就绪。首次使用请在下方配置API密钥。",13,SECONDARY,false);inputCard.addView(status);

        root.addView(gap(14));
        LinearLayout configCard=card(root);
        Button toggle=button("02 · API配置（展开 / 收起）",false);configCard.addView(toggle);
        settingsArea=new LinearLayout(this);settingsArea.setOrientation(LinearLayout.VERTICAL);settingsArea.setVisibility(View.GONE);
        configCard.addView(settingsArea);
        toggle.setOnClickListener(v->settingsArea.setVisibility(settingsArea.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
        settingsArea.addView(label("API-Football v3 / api-sports 密钥",13,SECONDARY,false));
        apiKey=field("x-apisports-key",config.footballKey,true);settingsArea.addView(apiKey);
        settingsArea.addView(label("OpenAI兼容 Chat Completions 密钥（可选）",13,SECONDARY,false));
        aiKey=field("AI API Key",config.aiKey,true);settingsArea.addView(aiKey);
        aiEndpoint=field("AI接口URL",config.aiEndpoint,false);settingsArea.addView(aiEndpoint);
        aiModel=field("AI模型名称",config.aiModel,false);settingsArea.addView(aiModel);
        deepCheck=new CheckBox(this);deepCheck.setText("深入比对过去2场首发（每队最多增加2次足球API请求）");
        deepCheck.setTextColor(WHITE);deepCheck.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        deepCheck.setChecked(config.rotationDeepCheck);settingsArea.addView(deepCheck);
        timingCheck=new CheckBox(this);timingCheck.setText("额外分析最近3场进球时间段：0–15 / 16–30 / 31–45分钟（最多额外6次足球API请求）");
        timingCheck.setTextColor(WHITE);timingCheck.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        timingCheck.setChecked(config.goalTimingCheck);settingsArea.addView(timingCheck);
        Button save=button("保存API设置（密钥本机加密）",true);settingsArea.addView(save);
        save.setOnClickListener(v->saveConfig());
        settingsArea.addView(label("只支持API-Football v3及OpenAI兼容的 /chat/completions 接口。密钥不会写入项目源代码或上传到我们的服务器。新闻RSS为独立公开来源。",11,SECONDARY,false));

        root.addView(gap(14));
        LinearLayout resultCard=card(root);resultCard.addView(label("03 · 研究报告",19,WHITE,true));
        resultCard.addView(label("先显示可验证事实，再显示AI推论；没有证据一律标记未知。",12,SECONDARY,false));
        aiContent=label("等待研究…",14,WHITE,false);resultCard.addView(aiContent);
        Button showDetails=button("查看 / 收起 原始统计与半场比分",false);resultCard.addView(showDetails);
        detailArea=new LinearLayout(this);detailArea.setOrientation(LinearLayout.VERTICAL);detailArea.setVisibility(View.GONE);
        factsContent=label("",12,WHITE,false);detailArea.addView(factsContent);
        resultCard.addView(detailArea);
        showDetails.setOnClickListener(v->{detailsOpen=!detailsOpen;detailArea.setVisibility(detailsOpen?View.VISIBLE:View.GONE);});
        warningsContent=label("",12,WARN,false);resultCard.addView(warningsContent);
        Button copy=button("复制完整研究报告",false);resultCard.addView(copy);
        copy.setOnClickListener(v->{if(latest==null){toast("还没有报告");return;}
            ClipboardManager cb=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cb.setPrimaryClip(ClipData.newPlainText("赛前研究",latest.ai+"\n\n"+latest.facts+"\n"+latest.warnings));toast("已复制");});

        root.addView(gap(14));
        LinearLayout newsCard=card(root);
        newsCard.addView(label("04 · 相关新闻来源（可点开原文）",19,WHITE,true));
        newsCard.addView(label("只展示赛前21天内检索到的RSS新闻标题；标题不能视为已经确认的伤停或轮换。",12,SECONDARY,false));
        newsContainer=new LinearLayout(this);newsContainer.setOrientation(LinearLayout.VERTICAL);newsCard.addView(newsContainer);
        newsContainer.addView(label("等待搜索…",13,SECONDARY,false));
        root.addView(gap(14));
        root.addView(label("独立Android应用 · 无投注执行功能 · 需要网络及用户自备API密钥",11,SECONDARY,false));
    }
    private void saveConfig() {
        String endpoint=aiEndpoint.getText().toString().trim();
        if(!endpoint.startsWith("https://") || !endpoint.endsWith("/chat/completions")){toast("AI接口须为HTTPS的 /chat/completions 完整地址");return;}
        try{
            SecretStore.save(this,"football",apiKey.getText().toString().trim());
            SecretStore.save(this,"ai",aiKey.getText().toString().trim());
            config.footballKey=apiKey.getText().toString().trim();config.aiKey=aiKey.getText().toString().trim();
            config.aiEndpoint=endpoint;config.aiModel=aiModel.getText().toString().trim();
            config.rotationDeepCheck=deepCheck.isChecked();config.goalTimingCheck=timingCheck.isChecked();
            if(config.aiModel.isEmpty()){toast("请填写AI模型名称");return;}
            prefs.edit().putString("ai_endpoint",endpoint).putString("ai_model",config.aiModel)
                .putBoolean("rotation",config.rotationDeepCheck).putBoolean("timing",config.goalTimingCheck).apply();
            toast("配置已保存，密钥由Android KeyStore加密");
            settingsArea.setVisibility(View.GONE);
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("密钥保存失败").setMessage(e.getMessage()).setPositiveButton("确定",null).show();}
    }
    private void runAnalysis(){
        // When settings are expanded, save explicitly first to prevent silently using stale keys.
        if(settingsArea.getVisibility()==View.VISIBLE) {toast("请先按“保存API设置”");return;}
        ResearchEngine.Input input=new ResearchEngine.Input();
        input.fixtureId=fixtureId.getText().toString().trim();
        input.homeName=home.getText().toString().trim();input.awayName=away.getText().toString().trim();
        input.screenshotTime=screenshotKickoff;
        if(input.fixtureId.isEmpty() && (input.homeName.isEmpty()||input.awayName.isEmpty())){toast("请输入Fixture ID，或两队的名称");return;}
        analyzeButton.setEnabled(false);status.setText("正在获取资料…");
        aiContent.setText("研究进行中，请勿将尚未核对的消息当作伤停事实。");
        factsContent.setText("");warningsContent.setText("");newsContainer.removeAllViews();
        worker.execute(()->{
            try {
                ResearchEngine.Report result=ResearchEngine.run(input,config,message->runOnUiThread(()->status.setText(message)));
                runOnUiThread(()->render(result));
            }catch(Exception e){runOnUiThread(()->{analyzeButton.setEnabled(true);status.setText("研究失败："+e.getMessage());});}
        });
    }
    private void render(ResearchEngine.Report result){
        analyzeButton.setEnabled(true);latest=result;status.setText("已完成。这是一次即时研究，非后台持续监测。");
        aiContent.setText("资料质量："+result.quality+"\n\n【AI综合研究】\n"+result.ai);
        factsContent.setText(result.facts);
        warningsContent.setText(result.warnings.isEmpty()?"":("【数据缺口 / 需人工复核】\n"+result.warnings));
        newsContainer.removeAllViews();
        if(result.news.isEmpty())newsContainer.addView(label("未取得赛前21天内的RSS新闻，建议手工核对俱乐部官网。",13,WARN,false));
        for(ResearchEngine.News item:result.news){
            TextView link=label(item.team+" · "+item.title+"\n来源："+item.source,13,ACCENT,false);
            link.setPadding(dp(8),dp(12),dp(8),dp(12));
            link.setBackground(box(CARD2,11));newsContainer.addView(link,new LinearLayout.LayoutParams(-1,-2));
            newsContainer.addView(gap(7));
            link.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(item.url)));}catch(Exception e){toast("无法打开文章来源");}});
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=PICK_IMAGE||result!=RESULT_OK||data==null||data.getData()==null)return;
        try{
            InputImage image=InputImage.fromFilePath(this,data.getData());
            ocrPreview.setText("正在识别截图中的球队与Fixture ID…");
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                .addOnSuccessListener(text->parseOCR(text.getText()))
                .addOnFailureListener(error->ocrPreview.setText("OCR失败："+error.getMessage()+"；请手动输入Fixture ID。"));
        }catch(Exception e){ocrPreview.setText("无法读取此图片："+e.getMessage());}
    }
    private void parseOCR(String raw){
        Matcher id=Pattern.compile("(?i)(?:fixture\\s*(?:id|#)|赛事\\s*(?:id|编号))\\s*[:：#-]?\\s*(\\d{4,12})").matcher(raw);
        if(id.find())fixtureId.setText(id.group(1));
        else {
            Matcher fallback=Pattern.compile("(?m)\\b(\\d{7,9})\\b").matcher(raw);
            if(fallback.find())fixtureId.setText(fallback.group(1));
        }
        for(String line:raw.split("\\r?\\n")) {
            Matcher team=Pattern.compile("(?iu)^\\s*(.+?)\\s+vs\\.?\\s+(.+?)\\s*$").matcher(line.trim());
            if(team.find()){
                home.setText(team.group(1).trim());away.setText(team.group(2).trim());break;
            }
        }
        Matcher clock=Pattern.compile("\\b(20[0-9]{2}[-/.][0-9]{1,2}[-/.][0-9]{1,2}\\s+[0-2]?[0-9]:[0-5][0-9])\\b").matcher(raw);
        screenshotKickoff=clock.find()?clock.group(1):"";
        String idText=fixtureId.getText().toString(),hn=home.getText().toString(),an=away.getText().toString();
        ocrPreview.setText("识别完成：Fixture ID "+(idText.isEmpty()?"未识别":idText)+"\n"+hn+" vs "+an+
            (screenshotKickoff.isEmpty()?"":"\n截图时间："+screenshotKickoff+"（截图时区未知）")+
            "\n请核对后点击研究；以足球API返回的Fixture ID资料为准。");
    }
    private LinearLayout card(LinearLayout parent){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(13),dp(14),dp(13),dp(15));
        l.setBackground(box(CARD,16));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(4);parent.addView(l,lp);return l;
    }
    private GradientDrawable box(int color,int radius){GradientDrawable bg=new GradientDrawable();bg.setColor(color);bg.setCornerRadius(dp(radius));return bg;}
    private TextView label(String content,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(content);t.setTextColor(color);t.setTextSize(size);
        t.setLineSpacing(dp(2),1f);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);t.setLayoutParams(p);return t;
    }
    private EditText field(String hint,String value,boolean secret){
        EditText input=new EditText(this);input.setSingleLine(true);input.setTextSize(15);
        input.setTextColor(WHITE);input.setHintTextColor(SECONDARY);input.setHint(hint);input.setText(value);
        input.setPadding(dp(10),dp(10),dp(10),dp(10));input.setBackground(box(CARD2,10));
        if(secret)input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.bottomMargin=dp(10);input.setLayoutParams(lp);return input;
    }
    private Button button(String text,boolean important){
        Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setTextSize(14);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setTextColor(important?BG:ACCENT);b.setBackground(box(important?ACCENT:CARD2,12));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.bottomMargin=dp(10);b.setLayoutParams(lp);return b;
    }
    private View gap(int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return v;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
}
