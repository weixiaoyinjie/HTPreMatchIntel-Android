package com.htintel.news;

import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;

/** This engine deliberately separates API facts, RSS headlines, and AI opinions. */
final class ResearchEngine {
    private static final String FOOTBALL_ROOT = "https://v3.football.api-sports.io/";
    private static final int CONNECT_TIMEOUT_MS = 12000;
    private static final int READ_TIMEOUT_MS = 18000;

    static final class Config {
        String footballKey = "";
        String aiKey = "";
        String aiEndpoint = "https://api.openai.com/v1/chat/completions";
        String aiModel = "gpt-4.1-mini";
        boolean rotationDeepCheck = true;
        boolean goalTimingCheck = false;
    }
    static final class Input {
        String fixtureId = "";
        String homeName = "";
        String awayName = "";
        String screenshotTime = "";
    }
    static final class News {
        String team, title, source, url;
        long publicationMs;
    }
    static final class Report {
        String facts = "";
        String ai = "";
        String warnings = "";
        String quality = "待核验";
        final List<News> news = new ArrayList<>();
    }
    private static final class Match {
        int id, leagueId, season, homeId, awayId;
        long kickoff;
        String home, away, league, status;
    }
    private static final class TableRow {
        int rank, played, points, scored, conceded;
        String team;
    }
    private static final class Played {
        int id, homeId, awayId, halfHome, halfAway, fullHome, fullAway, leagueId;
        long time;
        String home, away;
    }
    private static final class Timing { String details; int calls; }
    private static final class Sample {
        String name, side;
        int count, scored, conceded, scoredGames, concededGames, zeroZero, twoPlus, win, draw, loss;
        int splitCount, splitScored, splitConceded;
        final LinkedHashMap<String,Integer> halfScores = new LinkedHashMap<>();
        final List<Played> played = new ArrayList<>();
    }

    interface Progress { void say(String message); }

    static Report run(Input input, Config config, Progress progress) {
        Report report = new Report();
        StringBuilder facts = new StringBuilder();
        StringBuilder warnings = new StringBuilder();
        Match match = null;
        List<Played> homeGames = Collections.emptyList(), awayGames = Collections.emptyList();
        Map<Integer,TableRow> standings = new HashMap<>();
        boolean footballReady = !config.footballKey.trim().isEmpty();
        boolean fixtureFound = false;
        boolean lineupAvailable = false;
        boolean injuryAvailable = false;
        int apiCalls = 0;
        String homeName = input.homeName.trim(), awayName = input.awayName.trim();

        if (footballReady && input.fixtureId.trim().matches("[0-9]{4,12}")) {
            progress.say("正在核对 Fixture ID 与官方比赛数据…");
            try {
                JSONArray a = api(config.footballKey, "fixtures?id=" + input.fixtureId.trim()); apiCalls++;
                if (a.length() > 0) {
                    JSONObject f = a.getJSONObject(0);
                    JSONObject meta = f.optJSONObject("fixture");
                    JSONObject league = f.optJSONObject("league");
                    JSONObject teams = f.optJSONObject("teams");
                    if (meta != null && league != null && teams != null) {
                        match = new Match();
                        match.id = meta.optInt("id");
                        match.kickoff = parseIso(meta.optString("date"));
                        match.status = sub(meta,"status").optString("short", "未知");
                        match.leagueId = league.optInt("id");
                        match.season = league.optInt("season");
                        match.league = league.optString("name");
                        JSONObject h = sub(teams,"home"), aTeam = sub(teams,"away");
                        match.homeId = h.optInt("id"); match.home = h.optString("name");
                        match.awayId = aTeam.optInt("id"); match.away = aTeam.optString("name");
                        homeName = match.home; awayName = match.away;
                        fixtureFound = match.id>0 && match.homeId>0 && match.awayId>0 && match.kickoff>0;
                    }
                }
                if (!fixtureFound) warnings.append("• 足球API找不到该Fixture ID：可能是比赛尚未收录或账号无覆盖。\n");
            } catch (Exception e) { warnings.append("• 比赛资料读取失败：").append(safeError(e)).append("\n"); }
        } else if (!footballReady) warnings.append("• 尚未配置足球API密钥，无法查询官方赛程与半场比分。\n");
        else warnings.append("• 请输入有效的数字 Fixture ID；只凭球队名不自动猜测比赛编号。\n");

        if (fixtureFound) {
            facts.append("【赛事核验 / 足球API】\n");
            facts.append(match.home).append(" vs ").append(match.away).append("\n");
            facts.append("Fixture ID：").append(match.id).append("\n");
            if(!input.screenshotTime.isEmpty())facts.append("截图识别时间：").append(input.screenshotTime).append("（原截图时区未知）\n");
            facts.append("联赛：").append(match.league).append(" / ").append(match.season).append("\n");
            facts.append("比赛状态：").append(match.status).append("\n");
            if(match.status.equals("PST")||match.status.equals("CANC")||match.status.equals("ABD")||match.status.equals("TBD"))
                warnings.append("• 比赛处于延期/取消/中断/时间未定状态，禁止当作正常赛前比赛分析。\n");
            facts.append("开赛时间：").append(fmt(match.kickoff, TimeZone.getDefault())).append("（本机时区）\n");
            facts.append("波兰时间：").append(fmt(match.kickoff, TimeZone.getTimeZone("Europe/Warsaw"))).append("\n");
            if (!input.homeName.isEmpty() && !normalize(input.homeName).equals(normalize(match.home))) {
                warnings.append("• 截图主队名与足球API返回名称不完全一致，已优先采用Fixture ID匹配结果。\n");
            }
            progress.say("读取双方最近比赛和联赛排名…");
            try { homeGames = recent(config.footballKey,match.homeId,match.kickoff,match.leagueId); apiCalls++; }
            catch(Exception e) { warnings.append("• 主队历史比赛缺失：").append(safeError(e)).append("\n"); }
            try { awayGames = recent(config.footballKey,match.awayId,match.kickoff,match.leagueId); apiCalls++; }
            catch(Exception e) { warnings.append("• 客队历史比赛缺失：").append(safeError(e)).append("\n"); }
            try { standings = table(config.footballKey,match.leagueId,match.season); apiCalls++; }
            catch(Exception e) { warnings.append("• 当前联赛排名不可用，不能分层比较对手强弱：").append(safeError(e)).append("\n"); }

            facts.append("\n【联赛位置及对手强弱】\n");
            facts.append(rankText(match.home,standings.get(match.homeId),standings.size()));
            facts.append(rankText(match.away,standings.get(match.awayId),standings.size()));
            if (standings.size() < 6) facts.append("本联赛没有足够完整的排名表，对手强弱标记为未知。\n");
            facts.append("\n【最近上半场表现 / 只取开赛前已经结束的同联赛比赛】\n");
            Sample home = compute(match.home, "主队",match.homeId, homeGames,true);
            Sample away = compute(match.away, "客队",match.awayId, awayGames,false);
            facts.append(sampleText(home,match.homeId,standings));
            facts.append(sampleText(away,match.awayId,standings));
            facts.append("\n【对手强弱分组】\n");
            facts.append(opponentText(homeGames,match.homeId,standings));
            facts.append(opponentText(awayGames,match.awayId,standings));
            facts.append("排名分组：前1/3强、中1/3中、后1/3弱；只作为粗略代理，绝非球队真实实力模型。\n");
            if(config.goalTimingCheck) {
                progress.say("额外读取近期进球事件，验证上半场进球时段…");
                Timing th=goalTiming(config.footballKey,match.home,match.homeId,homeGames);
                Timing ta=goalTiming(config.footballKey,match.away,match.awayId,awayGames);
                apiCalls+=th.calls+ta.calls;
                facts.append("\n【近3场上半场进球时段 / 额外事件接口】\n")
                    .append(th.details).append(ta.details)
                    .append("注意：事件数与半场比分无法核对的场次已经剔除；含乌龙球的场次不做进球归属推断。\n");
            }

            progress.say("检查伤停及赛前首发…");
            facts.append("\n【伤停 / 停赛】\n");
            try {
                JSONArray injuries = api(config.footballKey,"injuries?fixture="+match.id); apiCalls++;
                injuryAvailable = true;
                if (injuries.length() == 0) facts.append("接口没有返回伤停条目；不代表球队全员健康（低级别联赛可能缺报）。\n");
                else {
                    for(int i=0;i<Math.min(injuries.length(),18);i++) {
                        JSONObject entry = injuries.optJSONObject(i); if(entry==null)continue;
                        JSONObject player = sub(entry,"player"),team=sub(entry,"team");
                        facts.append("• ").append(team.optString("name","未知球队")).append("：")
                            .append(player.optString("name","未知球员")).append(" / ")
                            .append(player.optString("type","待核实")).append(" / ")
                            .append(player.optString("reason","原因未提供")).append("\n");
                    }
                }
            } catch(Exception e) { warnings.append("• 伤停信息没有成功读取：").append(safeError(e)).append("\n"); facts.append("无法获取。\n"); }
            facts.append("\n【首发和疑似轮换】\n");
            try {
                JSONArray currentLineups = api(config.footballKey,"fixtures/lineups?fixture="+match.id); apiCalls++;
                if(currentLineups.length()==0) facts.append("尚未取得官方首发；无法确认是否轮换。\n");
                else {
                    lineupAvailable = true;
                    for(int side=0;side<2;side++) {
                        int id=side==0?match.homeId:match.awayId;
                        String team=side==0?match.home:match.away;
                        List<Played> games=side==0?homeGames:awayGames;
                        JSONObject current = findLineup(currentLineups,id);
                        if(current==null){facts.append(team).append("：没有首发名单。\n"); continue;}
                        Map<Integer,String> starters=starting(current);
                        facts.append(team).append("：已获得").append(starters.size()).append("名首发；")
                            .append("主帅 ").append(sub(current,"coach").optString("name","未知")).append("。\n");
                        if(config.rotationDeepCheck && starters.size()>=10) {
                            Map<Integer,Integer> freq = new HashMap<>();
                            Map<Integer,String> known = new HashMap<>();
                            int baselineGames=0;
                            for(Played past : games) {
                                if(baselineGames>=2)break;
                                try {
                                    JSONArray old = api(config.footballKey,"fixtures/lineups?fixture="+past.id); apiCalls++;
                                    JSONObject previous = findLineup(old,id);
                                    if(previous==null)continue;
                                    Map<Integer,String> oldXI=starting(previous);
                                    if(oldXI.size()<10)continue;
                                    baselineGames++;
                                    for(Map.Entry<Integer,String> it:oldXI.entrySet()) {
                                        freq.put(it.getKey(),freq.containsKey(it.getKey())?freq.get(it.getKey())+1:1);
                                        known.put(it.getKey(),it.getValue());
                                    }
                                } catch(Exception e){ warnings.append("• 过去首发比对部分失败：").append(safeError(e)).append("\n"); }
                            }
                            if(baselineGames<2) facts.append("过去两场首发资料不足，无法可靠计算轮换。\n");
                            else {
                                List<String> absent=new ArrayList<>();
                                List<String> bench=new ArrayList<>();
                                Set<Integer> subs = substitutes(current);
                                for(Integer pid:freq.keySet()) if(freq.get(pid)==2 && !starters.containsKey(pid)) {
                                    String name=known.get(pid);
                                    if(subs.contains(pid))bench.add(name); else absent.add(name);
                                }
                                facts.append("过去连续2场首发、今天未首发：").append(absent.size()+bench.size()).append("人；其中替补席")
                                    .append(bench.size()).append("人，未列入首发及替补").append(absent.size()).append("人。\n");
                                if(!bench.isEmpty())facts.append("在替补席：").append(String.join("、",bench)).append("\n");
                                if(!absent.isEmpty())facts.append("未在名单：").append(String.join("、",absent)).append("\n");
                                facts.append("注意：连续2场首发仅是常用球员代理，不能据此认定其是核心或受伤。\n");
                            }
                        } else if(!config.rotationDeepCheck) facts.append("未开启历史首发比对，轮换状态未知。\n");
                    }
                }
            } catch(Exception e) { warnings.append("• 首发接口未提供数据：").append(safeError(e)).append("\n"); facts.append("不可用，轮换未知。\n"); }
            int valid = Math.min(home.count,away.count);
            facts.append("\n【数据覆盖审查】\n");
            if(valid>=8 && standings.size()>=12)facts.append("历史半场样本：较充分（仍不是胜率保证）。\n");
            else if(valid>=4)facts.append("历史半场样本：有限，结论须降权。\n");
            else facts.append("历史半场样本不足（至少一方少于4场），不宜形成明确比分判断。\n");
            if(valid<4)report.quality="PASS · 至少一方半场样本少于4场";
            else if(valid<8||standings.size()<10)report.quality="C级 · 样本或对手排名覆盖有限";
            else if(!lineupAvailable || !injuryAvailable)report.quality="B级 · 半场样本可用，但阵容/伤停存在信息缺口";
            else report.quality="A级 · 结构化资料覆盖较完整（仍需核实新闻）";
            if(match.status.equals("PST")||match.status.equals("CANC")||match.status.equals("ABD")||match.status.equals("TBD"))
                report.quality="PASS · 比赛状态异常";
            facts.append("资料质量评级：").append(report.quality).append("。不是比赛胜率或投注评级。\n");
            facts.append("官方首发：").append(lineupAvailable?"已取得":"缺失或未公布").append("；伤停端点：").append(injuryAvailable?"请求成功":"不可用").append("。\n");
        } else {
            facts.append("【比赛识别】\n");
            facts.append("Fixture ID：").append(input.fixtureId).append("\n主队：").append(homeName).append("\n客队：").append(awayName).append("\n");
            facts.append("比赛未通过足球API唯一核验，以下只允许查看相关新闻标题，禁止编造进球统计与对手排名。\n");
            report.quality="PASS · 比赛身份未核验";
        }

        if (!homeName.isEmpty() && !awayName.isEmpty()) {
            progress.say("检索两队赛前新闻标题及来源…");
            long upper = match != null ? match.kickoff : System.currentTimeMillis();
            try { report.news.addAll(news(homeName,upper)); }
            catch (Exception e) { warnings.append("• 主队RSS新闻检索失败：").append(safeError(e)).append("\n"); }
            try { report.news.addAll(news(awayName,upper)); }
            catch (Exception e) { warnings.append("• 客队RSS新闻检索失败：").append(safeError(e)).append("\n"); }
            facts.append("\n【新闻与证据】\n");
            if(report.news.isEmpty())facts.append("没有检索到符合赛前时间窗的RSS文章；不等于球队无重要新闻。需要人工打开官方站点补查。\n");
            for(News n : report.news) {
                facts.append("• [").append(n.team).append("] ").append(n.title).append("\n")
                    .append("  来源：").append(n.source).append("；发布时间：").append(fmt(n.publicationMs,TimeZone.getDefault()))
                    .append("\n  链接：").append(n.url).append("\n");
            }
            facts.append("提示：目前新闻源只提供RSS标题及链接，未提取全文；伤病、轮换报道需要打开原文确认。\n");
        } else warnings.append("• 球队名称缺失，新闻搜索跳过。可手动输入两队名称。\n");

        facts.append("\n【分析边界】\n");
        facts.append("• 近期联赛数据依据API返回的比赛与上半场比分；缺失值不当作0。\n");
        facts.append("• 无xG、完整官方伤停或首发时，一律标为未知。\n");
        facts.append("• 对手强弱来自现有联赛排名，非历史赛前排名，可能有时间偏差。\n");
        facts.append("• 复盘已结束的旧比赛时，新闻检索及最近N场接口不能保证完整历史截面。\n");
        facts.append("• 新闻、阵容只是资料审查，不直接生成投注建议。\n");
        facts.append("足球API请求估算：").append(apiCalls).append("次；新闻RSS：最多2次。\n");
        report.facts=facts.toString(); report.warnings=warnings.toString();

        if(!config.aiKey.trim().isEmpty()) {
            progress.say("调用AI API做有来源的中文研究摘要…");
            try {report.ai=ai(config,report.facts,report.warnings);}
            catch(Exception e) {report.ai="AI分析暂不可用："+safeError(e)+"\n仍可使用上方的足球API客观数据。";}
        } else report.ai="未配置AI API密钥；以上为本机整理的结构化客观资料。";
        return report;
    }

    private static String rankText(String team,TableRow row,int count) {
        if(row==null)return team+"：无可靠联赛排名资料。\n";
        return team+"：第"+row.rank+"/"+count+"名，"+row.played+"场 "+row.points+"分，进"+row.scored+"/失"+row.conceded+"球。\n";
    }
    private static Sample compute(String name,String side,int teamId,List<Played> matches,boolean isHomeSide) {
        Sample s=new Sample();s.name=name;s.side=side;
        for(Played p:matches) {
            boolean asHome=p.homeId==teamId;
            int gf=asHome?p.halfHome:p.halfAway;
            int ga=asHome?p.halfAway:p.halfHome;
            int fullFor=asHome?p.fullHome:p.fullAway;
            int fullAgainst=asHome?p.fullAway:p.fullHome;
            s.count++;s.scored+=gf;s.conceded+=ga;
            if(gf>0)s.scoredGames++;if(ga>0)s.concededGames++;
            if(gf==0&&ga==0)s.zeroZero++;
            if(gf+ga>=2)s.twoPlus++;
            if(fullFor>fullAgainst)s.win++;else if(fullFor==fullAgainst)s.draw++;else s.loss++;
            String score=gf+"-"+ga;
            s.halfScores.put(score,s.halfScores.containsKey(score)?s.halfScores.get(score)+1:1);
            if(asHome==isHomeSide){s.splitCount++;s.splitScored+=gf;s.splitConceded+=ga;}
            s.played.add(p);
        }
        return s;
    }
    private static String sampleText(Sample s,int teamId,Map<Integer,TableRow> table) {
        StringBuilder b=new StringBuilder();b.append("\n").append(s.name).append("（").append(s.side).append("）：").append(s.count).append("场\n");
        if(s.count==0){b.append("缺乏有效半场比分，不计算平均或趋势。\n");return b.toString();}
        b.append("最近结果（全场）：").append(s.win).append("胜").append(s.draw).append("平").append(s.loss).append("负\n");
        b.append("半场场均进球/失球：").append(decimal(s.scored,s.count)).append(" / ").append(decimal(s.conceded,s.count)).append("\n");
        b.append("半场曾进球：").append(s.scoredGames).append("/").append(s.count)
            .append("；半场曾丢球：").append(s.concededGames).append("/").append(s.count).append("\n");
        b.append("半场0-0：").append(s.zeroZero).append("/").append(s.count)
            .append("；双方合计至少2球：").append(s.twoPlus).append("/").append(s.count).append("\n");
        b.append(s.side.equals("主队")?"仅主场":"仅客场").append("：").append(s.splitCount).append("场，半场均进/失 ")
            .append(s.splitCount==0?"缺失":decimal(s.splitScored,s.splitCount)+" / "+decimal(s.splitConceded,s.splitCount)).append("\n");
        List<Map.Entry<String,Integer>> ranking=new ArrayList<>(s.halfScores.entrySet());
        ranking.sort((x,y)->Integer.compare(y.getValue(),x.getValue()));
        b.append("半场比分（本队视角）：");
        for(int i=0;i<Math.min(6,ranking.size());i++) {
            Map.Entry<String,Integer> x=ranking.get(i);
            b.append(x.getKey()).append("×").append(x.getValue()).append("；");
        }
        b.append("\n最近比赛：\n");
        for(int i=0;i<Math.min(10,s.played.size());i++) {
            Played p=s.played.get(i),dummy=p;
            int opp=p.homeId==teamId?p.awayId:p.homeId;
            TableRow row=table.get(opp);
            b.append("• ").append(shortDate(p.time)).append(" ").append(p.home).append(" ")
                .append(p.fullHome).append("-").append(p.fullAway).append(" ").append(p.away)
                .append("；半场").append(p.halfHome).append("-").append(p.halfAway)
                .append("；对手").append(row==null?"排名未知":"第"+row.rank+"名")
                .append("\n");
        }
        return b.toString();
    }
    private static Timing goalTiming(String key,String teamName,int teamId,List<Played> matches) {
        Timing t=new Timing();int[] scored=new int[3], conceded=new int[3];
        int valid=0,unavailable=0,ownGoals=0,penalties=0;
        for(int i=0;i<Math.min(3,matches.size());i++) {
            Played p=matches.get(i); t.calls++;
            try {
                JSONArray a=api(key,"fixtures/events?fixture="+p.id+"&type=Goal");
                int[] homeBand=new int[3],awayBand=new int[3];
                boolean unsafe=false;
                int penaltiesInGame=0;
                for(int j=0;j<a.length();j++) {
                    JSONObject event=a.optJSONObject(j);if(event==null)continue;
                    if(!"Goal".equalsIgnoreCase(event.optString("type")))continue;
                    String detail=event.optString("detail","");
                    if(detail.equalsIgnoreCase("Missed Penalty") || detail.toLowerCase(Locale.ROOT).contains("shootout"))continue;
                    JSONObject time=sub(event,"time");int minute=time.optInt("elapsed",0);
                    if(minute<=0 || minute>45)continue;
                    if(detail.toLowerCase(Locale.ROOT).contains("own goal")) {unsafe=true;ownGoals++;break;}
                    int scorer=sub(event,"team").optInt("id");
                    if(scorer!=p.homeId&&scorer!=p.awayId){unsafe=true;break;}
                    int bucket=minute<=15?0:(minute<=30?1:2);
                    if(scorer==p.homeId)homeBand[bucket]++;else awayBand[bucket]++;
                    if(detail.equalsIgnoreCase("Penalty"))penaltiesInGame++;
                }
                int h=homeBand[0]+homeBand[1]+homeBand[2],aGoals=awayBand[0]+awayBand[1]+awayBand[2];
                if(unsafe||h!=p.halfHome||aGoals!=p.halfAway){unavailable++;continue;}
                valid++;penalties+=penaltiesInGame;
                for(int k=0;k<3;k++) {
                    scored[k]+=teamId==p.homeId?homeBand[k]:awayBand[k];
                    conceded[k]+=teamId==p.homeId?awayBand[k]:homeBand[k];
                }
            }catch(Exception e){unavailable++;}
        }
        StringBuilder b=new StringBuilder(teamName+"：已核验 "+valid+" 场，事件缺失/不匹配 "+unavailable+" 场。\n");
        if(valid<2){b.append("样本不足2场，暂不能描述具体进球时段。\n");t.details=b.toString();return t;}
        String[] labels={"0–15分钟","16–30分钟","31–45分钟及上半场补时"};
        for(int i=0;i<3;i++)b.append(labels[i]).append("：本队进").append(scored[i]).append("/失").append(conceded[i]).append("球\n");
        b.append("已核验事件中的点球：").append(penalties).append("个；小样本不应直接转化成精确胜率。\n");
        t.details=b.toString();return t;
    }
    private static String opponentText(List<Played> matches,int teamId,Map<Integer,TableRow> table) {
        if(table.size()<6)return "球队ID "+teamId+"：排名样本缺失，不能区分强弱对手。\n";
        int[] n=new int[3],scored=new int[3],allowed=new int[3];
        for(Played p:matches) {
            int opp=p.homeId==teamId?p.awayId:p.homeId;
            TableRow r=table.get(opp); if(r==null)continue;
            int zone=r.rank<=(table.size()+2)/3?0:(r.rank>(2*table.size())/3?2:1);
            n[zone]++;
            scored[zone]+=p.homeId==teamId?p.halfHome:p.halfAway;
            allowed[zone]+=p.homeId==teamId?p.halfAway:p.halfHome;
        }
        StringBuilder b=new StringBuilder("球队ID "+teamId+"：");String[] labels={"强","中","弱"};
        for(int i=0;i<3;i++)b.append(labels[i]).append("对手").append(n[i]).append("场")
            .append(n[i]>0?"(半场均进/失 "+decimal(scored[i],n[i])+"/"+decimal(allowed[i],n[i])+")":"")
            .append("；");
        return b.append("\n").toString();
    }
    private static String decimal(int a,int b){return String.format(Locale.US,"%.2f",a/(double)b);}
    private static List<Played> recent(String key,int team,long kickoff,int leagueId)throws Exception {
        JSONArray array=api(key,"fixtures?team="+team+"&last=30");
        List<Played> out=new ArrayList<>();
        for(int i=0;i<array.length();i++) {
            JSONObject f=array.optJSONObject(i);if(f==null)continue;
            JSONObject fixture=sub(f,"fixture"),status=sub(fixture,"status");
            String s=status.optString("short");if(!s.equals("FT")&&!s.equals("AET")&&!s.equals("PEN"))continue;
            long time=parseIso(fixture.optString("date"));
            if(time<=0 || (kickoff>0&&time>=kickoff))continue;
            if(sub(f,"league").optInt("id")!=leagueId)continue;
            JSONObject score=sub(f,"score"),ht=sub(score,"halftime"),ft=sub(score,"fulltime");
            if(ht.isNull("home")||ht.isNull("away")||!ht.has("home")||!ht.has("away")||
               ft.isNull("home")||ft.isNull("away")||!ft.has("home")||!ft.has("away"))continue;
            JSONObject teams=sub(f,"teams"), h=sub(teams,"home"),a=sub(teams,"away");
            Played p=new Played();p.id=fixture.optInt("id");p.time=time;
            p.homeId=h.optInt("id");p.awayId=a.optInt("id");
            p.home=h.optString("name");p.away=a.optString("name");
            p.leagueId=sub(f,"league").optInt("id");
            p.halfHome=ht.optInt("home");p.halfAway=ht.optInt("away");
            p.fullHome=ft.optInt("home");p.fullAway=ft.optInt("away");
            out.add(p);
        }
        out.sort((x,y)->Long.compare(y.time,x.time));
        if(out.size()>10)return new ArrayList<>(out.subList(0,10));
        return out;
    }
    private static Map<Integer,TableRow> table(String key,int leagueId,int season)throws Exception {
        Map<Integer,TableRow> result=new HashMap<>();
        JSONArray arr=api(key,"standings?league="+leagueId+"&season="+season);
        for(int i=0;i<arr.length();i++) {
            JSONObject data=arr.optJSONObject(i);if(data==null)continue;
            JSONArray groups=sub(data,"league").optJSONArray("standings");if(groups==null)continue;
            for(int j=0;j<groups.length();j++) {
                JSONArray group=groups.optJSONArray(j);if(group==null)continue;
                for(int k=0;k<group.length();k++) {
                    JSONObject o=group.optJSONObject(k);if(o==null)continue;
                    JSONObject team=sub(o,"team"),all=sub(o,"all"),goals=sub(all,"goals");
                    TableRow r=new TableRow();r.rank=o.optInt("rank");r.points=o.optInt("points");
                    r.played=all.optInt("played");r.scored=goals.optInt("for");r.conceded=goals.optInt("against");
                    r.team=team.optString("name");int id=team.optInt("id");
                    if(id>0)result.put(id,r);
                }
            }
        }
        return result;
    }
    private static JSONObject findLineup(JSONArray all,int teamId) {
        for(int i=0;i<all.length();i++) {
            JSONObject o=all.optJSONObject(i);
            if(o!=null && sub(o,"team").optInt("id")==teamId)return o;
        }return null;
    }
    private static Map<Integer,String> starting(JSONObject o) {
        Map<Integer,String> list=new LinkedHashMap<>();JSONArray a=o.optJSONArray("startXI");if(a==null)return list;
        for(int i=0;i<a.length();i++){JSONObject p=sub(a.optJSONObject(i),"player");int id=p.optInt("id");if(id>0)list.put(id,p.optString("name"));}
        return list;
    }
    private static Set<Integer> substitutes(JSONObject o) {
        Set<Integer> ids=new HashSet<>();JSONArray a=o.optJSONArray("substitutes");if(a==null)return ids;
        for(int i=0;i<a.length();i++){int id=sub(a.optJSONObject(i),"player").optInt("id");if(id>0)ids.add(id);}
        return ids;
    }
    private static List<News> news(String team,long upper)throws Exception {
        String query="\""+team+"\" when:21d";
        String url="https://news.google.com/rss/search?q="+Uri.encode(query)+"&hl=pl&gl=PL&ceid=PL:pl";
        HttpURLConnection c=connection(url,"GET");
        if(c.getResponseCode()!=200)throw new Exception("RSS HTTP "+c.getResponseCode());
        List<News> list=new ArrayList<>();
        try(InputStream stream=c.getInputStream()) {
            DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities",false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);
            factory.setXIncludeAware(false);factory.setExpandEntityReferences(false);
            Document document=factory.newDocumentBuilder().parse(stream);
            NodeList nodes=document.getElementsByTagName("item");
            for(int i=0;i<nodes.getLength()&&list.size()<6;i++) {
                Element item=(Element)nodes.item(i);
                News n=new News();n.team=team;n.title=xmlText(item,"title");n.url=xmlText(item,"link");
                n.source=xmlText(item,"source");n.publicationMs=parseRssDate(xmlText(item,"pubDate"));
                if(n.publicationMs==0 || n.publicationMs>upper || n.publicationMs<upper-21L*86400000L)continue;
                if(n.title.isEmpty()||!n.url.startsWith("https://"))continue;
                list.add(n);
            }
        } finally {c.disconnect();}
        return list;
    }
    private static String xmlText(Element e,String tag){NodeList l=e.getElementsByTagName(tag);return l.getLength()==0?"":l.item(0).getTextContent().trim();}
    private static long parseRssDate(String text) {
        try{SimpleDateFormat fmt=new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z",Locale.ENGLISH);return fmt.parse(text).getTime();}
        catch(Exception e){return 0;}
    }
    private static String ai(Config cfg,String facts,String warnings)throws Exception {
        if(!cfg.aiEndpoint.trim().startsWith("https://"))throw new Exception("AI接口必须使用HTTPS");
        HttpURLConnection c=connection(cfg.aiEndpoint.trim(),"POST");
        c.setDoOutput(true);c.setRequestProperty("Authorization","Bearer "+cfg.aiKey.trim());
        c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        JSONObject system=new JSONObject().put("role","system").put("content",
            "你是中文足球赛前情报核查分析师。必须严格分开：1)API结构化数据；2)新闻RSS标题（未经全文验证）；3)你的推断。"+
            "不得杜撰伤病、首发、媒体报道或上半场比分。无法核实写未知。"+
            "针对主队主场与客队客场的上半场进球/失球模式、对手强弱、近期状态、阵容风险，"+
            "给出真实证据、样本量、反例与信息质量评级（A/B/C/PASS代表资料可信度，不代表下注建议）。"+
            "输出固定段落：核心情报；主队进攻与防守；客队进攻与防守；半场特征；对手强弱校正；近期新闻及来源；阵容风险；最大不确定性；资料质量评级。"+
            "对于只见标题的新闻，只写标题提示可能关注的事项，不可直接断言消息属实。不要推荐投注额或保证准确率。");
        JSONObject user=new JSONObject().put("role","user").put("content","根据以下数据做客观审查，请勿捏造：\n"+facts+"\n缺陷：\n"+warnings);
        JSONObject payload=new JSONObject().put("model",cfg.aiModel.trim())
            .put("messages",new JSONArray().put(system).put(user)).put("temperature",0.2).put("max_tokens",2200);
        byte[] bytes=payload.toString().getBytes(StandardCharsets.UTF_8);
        try(OutputStream out=c.getOutputStream()){out.write(bytes);}
        int status=c.getResponseCode();
        String raw=read(c,status<400);
        c.disconnect();
        if(status>=400)throw new Exception("HTTP "+status+"："+truncate(raw,260));
        JSONObject r=new JSONObject(raw);JSONArray choices=r.optJSONArray("choices");
        if(choices==null||choices.length()==0)throw new Exception("AI响应没有choices");
        String content=sub(choices.optJSONObject(0),"message").optString("content","");
        if(content.isEmpty())throw new Exception("AI输出为空");
        return content;
    }
    private static JSONArray api(String key,String path)throws Exception {
        HttpURLConnection c=connection(FOOTBALL_ROOT+path,"GET");
        c.setRequestProperty("x-apisports-key",key.trim());
        int status=c.getResponseCode();String raw=read(c,status<400);c.disconnect();
        if(status>=400)throw new Exception("API HTTP "+status+" "+truncate(raw,140));
        JSONObject data=new JSONObject(raw);
        Object errors=data.opt("errors");
        if(errors instanceof JSONObject && ((JSONObject)errors).length()>0)throw new Exception("API错误："+truncate(errors.toString(),150));
        if(errors instanceof JSONArray && ((JSONArray)errors).length()>0)throw new Exception("API错误："+truncate(errors.toString(),150));
        JSONArray result=data.optJSONArray("response");
        return result==null?new JSONArray():result;
    }
    private static HttpURLConnection connection(String url,String method)throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(CONNECT_TIMEOUT_MS);c.setReadTimeout(READ_TIMEOUT_MS);
        c.setRequestMethod(method);c.setRequestProperty("User-Agent","HTPreMatchIntel/1.0 Android");
        c.setRequestProperty("Accept","application/json,application/rss+xml,application/xml,text/xml");
        return c;
    }
    private static String read(HttpURLConnection c,boolean good)throws Exception {
        InputStream in=good?c.getInputStream():c.getErrorStream();if(in==null)return "(empty)";
        try(InputStream stream=in;BufferedReader br=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){
            StringBuilder s=new StringBuilder();String line;while((line=br.readLine())!=null){s.append(line).append('\n');if(s.length()>600000)break;}return s.toString();
        }
    }
    private static JSONObject sub(JSONObject obj,String key){return obj==null?new JSONObject():obj.optJSONObject(key)==null?new JSONObject():obj.optJSONObject(key);}
    private static long parseIso(String iso) {try{return OffsetDateTime.parse(iso).toInstant().toEpochMilli();}catch(Exception e){return 0;}}
    private static String fmt(long time,TimeZone zone){if(time<=0)return "未知";SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm z",Locale.CHINESE);df.setTimeZone(zone);return df.format(new Date(time));}
    private static String shortDate(long time){SimpleDateFormat df=new SimpleDateFormat("MM-dd",Locale.CHINESE);return df.format(new Date(time));}
    private static String normalize(String s){return s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]","");}
    private static String safeError(Exception e){return truncate(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage(),220);}
    private static String truncate(String s,int max){return s==null?"":(s.length()>max?s.substring(0,max)+"…":s);}
}
